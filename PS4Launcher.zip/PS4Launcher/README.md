# Launcher untuk Android (v1.3.0)

Tampilan dan fitur = `app/index.html` dari versi Electron (PC), dijalankan di WebView.
`app/src/main/assets/android.js` menggantikan `preload.js` (jembatan ke Android),
`MainActivity.kt` menggantikan `main.js`.

Perubahan kecil di index.html (hanya 7 baris): CSP connect-src, load android.js, fileUrl untuk Android,
dua label menu Add Game, teks versi, dan teks kembali ke launcher.

Android vs PC:
- Add Game > "Choose Android app(s)": pilih app terpasang. "Choose file from phone": satu file (dibuka dengan app bawaan).
- Launcher kembali sendiri saat kamu kembali dari app (tidak bisa mendeteksi app benar-benar tertutup).
- Tombol Back Android = Esc. Tombol di footer layar (Enter, Back, Options, Details, Quick Menu) bisa di-tap.
- Screenshot (tombol S) menangkap layar launcher; disimpan di folder app (Capture Gallery).
- Create Desktop Shortcut = pasang shortcut app di layar utama HP.
- Ikon resmi/suara sendiri: ganti isi app/src/main/assets (sounds/*.mp3).
