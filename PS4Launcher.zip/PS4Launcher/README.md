# PS4 Launcher (Android, Jetpack Compose)
Buka folder ini di Android Studio (Koala+), tunggu Gradle sync, lalu Run / Build > Build APK.
Ikon resmi: taruh PNG di app/src/main/res/drawable dengan nama ic_<id>.png
(id: store, whatsnew, live, gallery, tv, www, psnow, music, headset, psvideo, share, youtube, library)
