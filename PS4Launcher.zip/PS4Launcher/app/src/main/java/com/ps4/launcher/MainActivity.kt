@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.ps4.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================ DATA ============================

enum class Scr { Users, Home, Library, Settings, Trophies, Friends, Notifications, Party }

class Opt(val label: String, val on: () -> Unit)
class Q(val id: String, val icon: String, val label: String, val on: () -> Unit)
class Fn(val id: String, val label: String, val icon: String)
class B(val id: String, val title: String, val bg: Color)

val W = Color.White
fun wa(a: Float) = Color.White.copy(alpha = a)

val FIXED = setOf("store", "whatsnew", "library")
val DEFAULT_HOME = listOf("live", "gallery", "tv", "www", "psnow")
val DARK = Color(0xFF123A9E)

val BUILTINS = listOf(
    B("store", "PlayStation Store", Color(0xFF0B3FB5)),
    B("whatsnew", "What's New", Color(0xFF3D6FE8)),
    B("live", "Live from PlayStation", DARK),
    B("gallery", "Capture Gallery", DARK),
    B("tv", "TV & Video", DARK),
    B("www", "Internet Browser", DARK),
    B("psnow", "PlayStation Now", Color(0xFF0B63D6)),
    B("music", "Media Player", DARK),
    B("headset", "Headset Companion App", DARK),
    B("psvideo", "PlayStation Video - My Videos", DARK),
    B("share", "SHAREfactory", DARK),
    B("youtube", "YouTube", Color(0xFFD32F2F)),
    B("library", "Library", DARK)
)

val FUNCS = listOf(
    Fn("plus", "PlayStation Plus", "plus"),
    Fn("notif", "Notifications", "info"),
    Fn("friends", "Friends", "friends"),
    Fn("comm", "Communities", "comm"),
    Fn("events", "Events", "events"),
    Fn("msg", "Messages", "msg"),
    Fn("party", "Party", "party"),
    Fn("profile", "Profile", "profile"),
    Fn("trophy", "Trophies", "trophy"),
    Fn("settings", "Settings", "settings"),
    Fn("power", "Power", "power")
)

val QITEMS = listOf(
    "close" to "Close Application", "sound" to "Sound/Devices", "media" to "Media Player",
    "np" to "Now Playing", "party" to "Party", "status" to "Online Status",
    "friends" to "Online Friends", "power" to "Power"
)

val TROPHIES = listOf(
    Triple("welcome", "Welcome Back", "Masuk dengan sebuah user"),
    Triple("firstapp", "First Launch", "Buka aplikasi pertama"),
    Triple("collector", "Collector", "Tambah app Android ke PS4"),
    Triple("tenth", "Dedicated", "Buka aplikasi 10 kali"),
    Triple("custom", "Personalizer", "Ubah tema atau urutan menu"),
    Triple("party", "Party Time", "Buka menu Party"),
    Triple("friend", "Friendly", "Tambah seorang teman")
)

val THEMES = listOf(
    listOf(Color(0xFF0A2278), Color(0xFF1B4BD0), Color(0xFF0A2A9C)),
    listOf(Color(0xFF02040C), Color(0xFF111A3A), Color(0xFF050A1E)),
    listOf(Color(0xFF3A0A0A), Color(0xFF9C1B1B), Color(0xFF4A0A12))
)
val THEME_NAMES = listOf("Blue (Default)", "Midnight", "Crimson")

// ============================ STATE ============================

class Vm(val ctx: Context) {
    private val sp = ctx.getSharedPreferences("ps4", Context.MODE_PRIVATE)
    private fun ls(k: String, d: String) = (sp.getString(k, d) ?: d).split("\n").filter { it.isNotBlank() }

    val users = mutableStateListOf<String>().apply { addAll(ls("users", "")) }
    val home = mutableStateListOf<String>().apply { addAll(ls("home", DEFAULT_HOME.joinToString("\n"))) }
    val lib = mutableStateListOf<String>().apply { addAll(ls("lib", "")) }
    val hiddenQ = mutableStateListOf<String>().apply { addAll(ls("hq", "")) }
    val friends = mutableStateListOf<String>().apply { addAll(ls("friends", "")) }
    val recent = mutableStateListOf<String>().apply { addAll(ls("recent", "")) }
    val trophies = mutableStateListOf<String>().apply { addAll(ls("tr", "")) }
    val counts = mutableStateMapOf<String, Int>().apply {
        ls("cnt", "").forEach { val p = it.split("|"); if (p.size == 2) put(p[0], p[1].toIntOrNull() ?: 0) }
    }

    var scr by mutableStateOf(Scr.Users)
    var user by mutableStateOf<String?>(null)
    var sort by mutableStateOf(sp.getString("sort", "default") ?: "default")
    var status by mutableStateOf(sp.getString("status", "Online") ?: "Online")
    var theme by mutableStateOf(sp.getInt("theme", 0))
    var nowPlaying by mutableStateOf<String?>(null)
    var func by mutableStateOf(false)
    var quick by mutableStateOf(false)
    var qsub by mutableStateOf(0)
    var power by mutableStateOf(false)
    var rest by mutableStateOf(0)
    var dlg by mutableStateOf<String?>(null)
    var optId by mutableStateOf<String?>(null)
    var friendSel by mutableStateOf<String?>(null)
    var delUser by mutableStateOf<String?>(null)

    private val labels = HashMap<String, String>()

    fun save() {
        sp.edit()
            .putString("users", users.joinToString("\n"))
            .putString("home", home.joinToString("\n"))
            .putString("lib", lib.joinToString("\n"))
            .putString("hq", hiddenQ.joinToString("\n"))
            .putString("friends", friends.joinToString("\n"))
            .putString("recent", recent.joinToString("\n"))
            .putString("tr", trophies.joinToString("\n"))
            .putString("cnt", counts.entries.joinToString("\n") { "${it.key}|${it.value}" })
            .putString("sort", sort)
            .putString("status", status)
            .putInt("theme", theme)
            .apply()
    }

    fun reset() {
        sp.edit().clear().apply()
        users.clear(); home.clear(); home.addAll(DEFAULT_HOME); lib.clear(); hiddenQ.clear()
        friends.clear(); recent.clear(); counts.clear(); trophies.clear()
        sort = "default"; status = "Online"; theme = 0; nowPlaying = null; user = null; scr = Scr.Users
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    fun unlock(id: String, name: String) {
        if (id !in trophies) { trophies.add(id); toast("Trophy: $name"); save() }
    }

    // ---------- helpers ----------
    fun label(pkg: String): String = labels.getOrPut(pkg) {
        try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
    }

    fun title(id: String): String = BUILTINS.firstOrNull { it.id == id }?.title ?: label(id.removePrefix("pkg:"))

    fun lastUsed(id: String): Long =
        recent.firstOrNull { it.startsWith("$id|") }?.substringAfter("|")?.toLongOrNull() ?: 0L

    fun isGame(id: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 26)
            ctx.packageManager.getApplicationInfo(id.removePrefix("pkg:"), 0).category == ApplicationInfo.CATEGORY_GAME
        else false
    } catch (e: Exception) { false }

    fun installed(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != ctx.packageName }
            .sortedBy { it.second.lowercase() }
    }

    fun battery(): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0) 0 else l * 100 / s
    }

    fun homeList(): List<String> {
        val mid = home.filter { it !in FIXED }
        val sorted = when (sort) {
            "name" -> mid.sortedBy { title(it).lowercase() }
            "recent" -> mid.sortedByDescending { lastUsed(it) }
            else -> mid
        }
        return listOf("store", "whatsnew") + sorted + listOf("library")
    }

    // ---------- launching ----------
    fun start(i: Intent) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
        catch (e: Exception) { toast("Tidak bisa membuka") }
    }

    fun url(u: String) = start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))

    fun settings(action: String) = start(Intent(action))

    fun openAny(pkgs: List<String>, fallbackUrl: String?) {
        for (p in pkgs) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p)
            if (i != null) { start(i); return }
        }
        if (fallbackUrl != null) url(fallbackUrl) else toast("Aplikasi tidak ditemukan")
    }

    fun gallery() {
        try {
            start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY))
        } catch (e: Exception) {
            start(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
        }
    }

    fun track(id: String) {
        nowPlaying = id
        recent.add(0, "$id|${System.currentTimeMillis()}")
        while (recent.size > 30) recent.removeAt(recent.lastIndex)
        counts[id] = (counts[id] ?: 0) + 1
        unlock("firstapp", "First Launch")
        if (counts.values.sum() >= 10) unlock("tenth", "Dedicated")
        save()
    }

    fun go(s: Scr) {
        scr = s; func = false; quick = false; qsub = 0
        if (s == Scr.Party) unlock("party", "Party Time")
    }

    fun open(id: String) {
        func = false; quick = false; qsub = 0
        if (id.startsWith("pkg:")) {
            val i = ctx.packageManager.getLaunchIntentForPackage(id.removePrefix("pkg:"))
            if (i == null) { toast("Aplikasi tidak ditemukan"); return }
            track(id); start(i); return
        }
        when (id) {
            "library" -> go(Scr.Library)
            "whatsnew" -> go(Scr.Notifications)
            "store" -> { track(id); openAny(listOf("com.scee.psxandroid"), "https://store.playstation.com") }
            "live" -> { track(id); openAny(listOf("tv.twitch.android.app", "com.google.android.youtube"), "https://www.twitch.tv") }
            "gallery" -> { track(id); gallery() }
            "tv" -> { track(id); openAny(listOf("com.netflix.mediaclient", "com.google.android.videos", "com.disney.disneyplus", "com.vidio.android", "com.amazon.avod.thirdpartyclient", "org.videolan.vlc"), "https://www.youtube.com") }
            "www" -> { track(id); url("https://www.google.com") }
            "psnow" -> { track(id); openAny(listOf("com.playstation.remoteplay"), "https://www.playstation.com/ps-now/") }
            "music" -> { track(id); start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)) }
            "headset" -> { track(id); settings(Settings.ACTION_BLUETOOTH_SETTINGS) }
            "psvideo" -> { track(id); start(Intent(Intent.ACTION_VIEW, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)) }
            "share" -> { track(id); openAny(listOf("com.google.android.apps.photos"), null) }
            "youtube" -> { track(id); openAny(listOf("com.google.android.youtube"), "https://www.youtube.com") }
        }
    }

    fun fn(id: String) {
        func = false
        when (id) {
            "plus" -> url("https://www.playstation.com/ps-plus/")
            "notif" -> go(Scr.Notifications)
            "friends" -> go(Scr.Friends)
            "comm" -> url("https://www.playstation.com/community/")
            "events" -> start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR))
            "msg" -> start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
            "party" -> go(Scr.Party)
            "profile" -> { scr = Scr.Users }
            "trophy" -> go(Scr.Trophies)
            "settings" -> go(Scr.Settings)
            "power" -> power = true
        }
    }

    fun closeApp() {
        val id = nowPlaying
        if (id == null) { toast("Tidak ada aplikasi yang berjalan"); return }
        if (id.startsWith("pkg:")) {
            try {
                (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
                    .killBackgroundProcesses(id.removePrefix("pkg:"))
            } catch (e: Exception) { }
        }
        toast("${title(id)} ditutup"); nowPlaying = null; quick = false; qsub = 0
    }

    // ---------- library / home ----------
    fun pin(id: String) { if (id !in home) home.add(id); save() }
    fun unpin(id: String) {
        if (id in FIXED) { toast("${title(id)} tidak bisa di-unpin"); return }
        home.remove(id); save()
    }
    fun toggleAndroid(pkg: String) {
        val id = "pkg:$pkg"
        if (id in lib) removeAndroid(pkg)
        else { lib.add(id); if (id !in home) home.add(id); unlock("collector", "Collector"); save() }
    }
    fun removeAndroid(pkg: String) { val id = "pkg:$pkg"; lib.remove(id); home.remove(id); save() }
    fun toggleQ(id: String) { if (id in hiddenQ) hiddenQ.remove(id) else hiddenQ.add(id); save() }

    fun login(name: String) { user = name; scr = Scr.Home; unlock("welcome", "Welcome Back") }
    fun addUser(n: String) { if (n !in users) users.add(n); save(); login(n) }
    fun addFriend(n: String) { if (n !in friends) friends.add(n); unlock("friend", "Friendly"); save() }

    fun back() {
        when {
            rest != 0 -> {}
            dlg != null -> dlg = null
            friendSel != null -> friendSel = null
            delUser != null -> delUser = null
            optId != null -> optId = null
            power -> power = false
            quick -> { if (qsub != 0) qsub = 0 else quick = false }
            func -> func = false
            scr == Scr.Home || scr == Scr.Users -> {}
            else -> scr = Scr.Home
        }
    }
}

// ============================ ACTIVITY ============================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        setContent { Ps4App() }
    }
}

@Composable
fun Ps4App() {
    val ctx = LocalContext.current
    val vm = remember { Vm(ctx) }
    BackHandler(true) { vm.back() }
    Box(Modifier.fillMaxSize()) {
        Bg(vm.theme)
        when (vm.scr) {
            Scr.Users -> UsersScreen(vm)
            Scr.Home -> HomeScreen(vm)
            Scr.Library -> LibraryScreen(vm)
            Scr.Settings -> SettingsScreen(vm)
            Scr.Trophies -> TrophiesScreen(vm)
            Scr.Friends -> FriendsScreen(vm)
            Scr.Notifications -> NotesScreen(vm)
            Scr.Party -> PartyScreen(vm)
        }
        FuncArea(vm)
        QuickMenu(vm)
        Dialogs(vm)
        if (vm.rest != 0) RestOverlay(vm)
    }
}

// ============================ COMMON UI ============================

@Composable
fun Bg(theme: Int) {
    val c = THEMES[theme.coerceIn(0, THEMES.lastIndex)]
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.linearGradient(c, Offset.Zero, Offset(size.width, size.height)))
        val r = size.height
        drawCircle(wa(0.06f), r * 1.2f, Offset(size.width * 0.25f, r * 1.7f), style = Stroke(r * 0.22f))
        drawCircle(wa(0.04f), r * 1.6f, Offset(size.width * 0.3f, r * 2.1f), style = Stroke(r * 0.2f))
    }
}

@Composable
fun Clock() {
    var t by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = SimpleDateFormat("h:mm a", Locale.getDefault())
        while (true) { t = f.format(Date()); delay(10_000) }
    }
    Text(t, color = W, fontSize = 16.sp)
}

@Composable
fun Avatar(name: String, size: Dp) {
    val h = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
    Box(Modifier.size(size).clip(CircleShape).background(Color.hsv(h, 0.55f, 0.75f)), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), color = W, fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PsBtn(text: String, on: () -> Unit) {
    Box(Modifier.border(1.dp, wa(0.7f)).clickable { on() }.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(text, color = W, fontSize = 14.sp)
    }
}

@Composable
fun Frame(vm: Vm, title: String, right: @Composable RowScope.() -> Unit = {}, body: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", color = W, fontSize = 32.sp, modifier = Modifier.clickable { vm.back() }.padding(start = 4.dp, end = 14.dp))
            Text(title, color = W, fontSize = 24.sp)
            Spacer(Modifier.weight(1f))
            right()
            Spacer(Modifier.width(12.dp))
            Clock()
        }
        Spacer(Modifier.height(8.dp))
        body()
    }
}

// ============================ ICONS ============================

@Composable
fun PsIcon(kind: String, modifier: Modifier = Modifier, tint: Color = W) {
    Canvas(modifier.aspectRatio(1f)) {
        val w = size.width
        val sw = w * 0.085f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun o(x: Float, y: Float) = Offset(w * x, w * y)
        fun sz(a: Float, b: Float) = Size(w * a, w * b)
        when (kind) {
            "plus" -> {
                val c = Color(0xFFFFC72C)
                drawLine(c, o(.5f, .1f), o(.5f, .9f), w * .24f)
                drawLine(c, o(.1f, .5f), o(.9f, .5f), w * .24f)
            }
            "info" -> {
                drawCircle(tint, w * .4f, o(.5f, .5f), style = st)
                drawLine(tint, o(.5f, .45f), o(.5f, .68f), sw * 1.3f, StrokeCap.Round)
                drawCircle(tint, sw * .8f, o(.5f, .3f))
            }
            "friends" -> {
                drawRoundRect(tint, o(.08f, .15f), sz(.5f, .5f), CornerRadius(w * .1f), st)
                drawRoundRect(tint, o(.38f, .38f), sz(.5f, .5f), CornerRadius(w * .1f), st)
                drawCircle(tint, sw * .7f, o(.33f, .4f)); drawCircle(tint, sw * .7f, o(.63f, .63f))
            }
            "comm", "face" -> {
                drawCircle(tint, w * .38f, o(.5f, .5f), style = st)
                drawCircle(tint, sw * .6f, o(.4f, .42f)); drawCircle(tint, sw * .6f, o(.6f, .42f))
                drawArc(tint, 20f, 140f, false, o(.33f, .36f), sz(.34f, .3f), style = st)
            }
            "events" -> {
                drawRoundRect(tint, o(.12f, .18f), sz(.76f, .7f), CornerRadius(w * .08f), st)
                drawLine(tint, o(.12f, .38f), o(.88f, .38f), sw)
                for (r in 0..1) for (c in 0..2) drawCircle(tint, sw * .55f, o(.3f + .2f * c, .55f + .18f * r))
            }
            "msg" -> {
                drawRoundRect(tint, o(.1f, .15f), sz(.8f, .55f), CornerRadius(w * .12f), st)
                val p = Path().apply { moveTo(w * .28f, w * .7f); lineTo(w * .28f, w * .9f); lineTo(w * .5f, w * .7f) }
                drawPath(p, tint, style = st)
            }
            "party" -> {
                drawArc(tint, 180f, 180f, false, o(.18f, .15f), sz(.64f, .64f), style = st)
                drawRoundRect(tint, o(.1f, .48f), sz(.18f, .3f), CornerRadius(w * .06f))
                drawRoundRect(tint, o(.72f, .48f), sz(.18f, .3f), CornerRadius(w * .06f))
            }
            "profile" -> {
                drawRoundRect(tint, o(.12f, .12f), sz(.76f, .76f), CornerRadius(w * .08f), st)
                drawCircle(tint, w * .12f, o(.5f, .4f))
                drawArc(tint, 200f, 140f, false, o(.3f, .55f), sz(.4f, .4f), style = st)
            }
            "trophy" -> {
                val p = Path().apply {
                    moveTo(w * .28f, w * .12f); lineTo(w * .72f, w * .12f); lineTo(w * .66f, w * .5f); lineTo(w * .34f, w * .5f); close()
                }
                drawPath(p, tint)
                drawArc(tint, 90f, 180f, false, o(.1f, .16f), sz(.26f, .26f), style = st)
                drawArc(tint, 270f, 180f, false, o(.64f, .16f), sz(.26f, .26f), style = st)
                drawLine(tint, o(.5f, .5f), o(.5f, .78f), sw)
                drawLine(tint, o(.32f, .84f), o(.68f, .84f), sw * 1.2f, StrokeCap.Round)
            }
            "settings" -> {
                drawRoundRect(tint, o(.1f, .34f), sz(.8f, .52f), CornerRadius(w * .08f))
                drawRoundRect(tint, o(.32f, .14f), sz(.36f, .24f), CornerRadius(w * .06f), st)
            }
            "power" -> {
                drawArc(tint, -60f, 300f, false, o(.18f, .2f), sz(.64f, .64f), style = st)
                drawLine(tint, o(.5f, .08f), o(.5f, .5f), sw * 1.2f, StrokeCap.Round)
            }
            "speaker" -> {
                val p = Path().apply {
                    moveTo(w * .12f, w * .4f); lineTo(w * .3f, w * .4f); lineTo(w * .5f, w * .22f)
                    lineTo(w * .5f, w * .78f); lineTo(w * .3f, w * .6f); lineTo(w * .12f, w * .6f); close()
                }
                drawPath(p, tint)
                drawArc(tint, -45f, 90f, false, o(.4f, .3f), sz(.4f, .4f), style = st)
            }
            "close" -> {
                drawCircle(tint, w * .36f, o(.5f, .5f), style = st)
                drawLine(tint, o(.25f, .75f), o(.75f, .25f), sw)
            }
            "play" -> {
                drawRoundRect(tint, o(.1f, .2f), sz(.8f, .6f), CornerRadius(w * .08f), st)
                val p = Path().apply { moveTo(w * .42f, w * .36f); lineTo(w * .42f, w * .64f); lineTo(w * .64f, w * .5f); close() }
                drawPath(p, tint)
            }
            "wrench" -> {
                drawCircle(tint, w * .2f, o(.38f, .38f), style = st)
                drawLine(tint, o(.5f, .5f), o(.85f, .85f), sw * 1.6f, StrokeCap.Round)
            }
            "lines" -> {
                drawLine(tint, o(.12f, .28f), o(.88f, .28f), sw)
                drawLine(tint, o(.12f, .5f), o(.7f, .5f), sw)
                drawLine(tint, o(.12f, .72f), o(.5f, .72f), sw)
            }
            "search" -> {
                drawCircle(tint, w * .26f, o(.42f, .42f), style = st)
                drawLine(tint, o(.62f, .62f), o(.88f, .88f), sw * 1.4f, StrokeCap.Round)
            }
            "grid" -> {
                for (r in 0..1) for (c in 0..1)
                    drawRoundRect(tint, o(.14f + .38f * c, .14f + .38f * r), sz(.32f, .32f), CornerRadius(w * .04f), st)
            }
            "gamepad" -> {
                drawRoundRect(tint, o(.08f, .28f), sz(.84f, .46f), CornerRadius(w * .2f), st)
                drawLine(tint, o(.28f, .42f), o(.28f, .6f), sw); drawLine(tint, o(.19f, .51f), o(.37f, .51f), sw)
                drawCircle(tint, sw * .6f, o(.68f, .45f)); drawCircle(tint, sw * .6f, o(.78f, .56f))
            }
            "bag" -> {
                drawRoundRect(tint, o(.18f, .3f), sz(.64f, .56f), CornerRadius(w * .05f), st)
                drawArc(tint, 180f, 180f, false, o(.35f, .12f), sz(.3f, .36f), style = st)
            }
            "gallery" -> {
                drawRoundRect(tint, o(.1f, .18f), sz(.8f, .64f), CornerRadius(w * .04f), st)
                val p = Path().apply {
                    moveTo(w * .14f, w * .78f); lineTo(w * .4f, w * .46f); lineTo(w * .56f, w * .64f)
                    lineTo(w * .68f, w * .52f); lineTo(w * .86f, w * .78f)
                }
                drawPath(p, tint, style = st)
                drawCircle(tint, w * .06f, o(.7f, .32f))
            }
            "tv" -> {
                drawRoundRect(tint, o(.1f, .2f), sz(.8f, .5f), CornerRadius(w * .03f), st)
                drawLine(tint, o(.35f, .82f), o(.65f, .82f), sw); drawLine(tint, o(.5f, .7f), o(.5f, .82f), sw)
            }
            "windows" -> {
                for (r in 0..1) for (c in 0..2) drawRect(tint, o(.1f + .28f * c, .28f + .24f * r), sz(.24f, .2f))
            }
            "shapes" -> {
                drawRect(tint, o(.14f, .14f), sz(.26f, .26f), style = st)
                drawCircle(tint, w * .14f, o(.72f, .72f), style = st)
                drawLine(tint, o(.16f, .6f), o(.38f, .82f), sw); drawLine(tint, o(.38f, .6f), o(.16f, .82f), sw)
                val p = Path().apply { moveTo(w * .72f, w * .14f); lineTo(w * .86f, w * .4f); lineTo(w * .58f, w * .4f); close() }
                drawPath(p, tint, style = st)
            }
            "books" -> {
                drawRoundRect(tint, o(.14f, .14f), sz(.32f, .72f), CornerRadius(w * .04f), st)
                drawRoundRect(tint, o(.54f, .14f), sz(.32f, .72f), CornerRadius(w * .04f), st)
            }
        }
    }
}

@Composable
fun Art(ctx: Context, id: String) {
    val res = remember(id) { ctx.resources.getIdentifier("ic_$id", "drawable", ctx.packageName) }
    val bmp = remember(id) {
        if (id.startsWith("pkg:")) {
            try { ctx.packageManager.getApplicationIcon(id.removePrefix("pkg:")).toBitmap(160, 160).asImageBitmap() }
            catch (e: Exception) { null }
        } else null
    }
    when {
        res != 0 -> Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        bmp != null -> Image(bmp, null, Modifier.fillMaxSize())
        else -> BuiltinArt(id)
    }
}

@Composable
fun BuiltinArt(id: String) {
    val m = Modifier.fillMaxSize(0.6f)
    when (id) {
        "store" -> { PsIcon("bag", m); Text("PS", color = W, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
        "whatsnew" -> PsIcon("shapes", m)
        "live" -> PsIcon("windows", m)
        "gallery" -> PsIcon("gallery", m)
        "tv" -> PsIcon("tv", m)
        "www" -> Text("www", color = W, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        "psnow" -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("PS", color = W, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, fontSize = 22.sp)
            Text("Now", color = W, fontSize = 12.sp)
        }
        "music" -> PsIcon("play", m)
        "headset" -> PsIcon("party", m)
        "psvideo" -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("PS", color = W, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, fontSize = 18.sp)
            Text("Video", color = W, fontSize = 12.sp)
        }
        "share" -> Text("SHARE\nfactory", color = W, fontSize = 12.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        "youtube" -> Text("YouTube", color = W, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        "library" -> PsIcon("books", m)
        else -> PsIcon("grid", m)
    }
}

fun bgOf(id: String): Color = BUILTINS.firstOrNull { it.id == id }?.bg ?: DARK

// ============================ USERS (foto 1) ============================

@Composable
fun UsersScreen(vm: Vm) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("PS4", color = W, fontSize = 30.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
        Spacer(Modifier.weight(0.5f))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Welcome Back to PlayStation", color = W, fontSize = 18.sp)
            Text("Who is using this controller?", color = wa(0.85f), fontSize = 14.sp)
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(Modifier.clickable { vm.dlg = "newuser" }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(100.dp).border(3.dp, W).background(wa(0.12f)), contentAlignment = Alignment.Center) {
                    Text("+", color = W, fontSize = 52.sp)
                }
                Spacer(Modifier.height(6.dp)); Text("New User", color = W, fontSize = 13.sp)
            }
            vm.users.toList().forEach { u ->
                Column(Modifier.combinedClickable(onClick = { vm.login(u) }, onLongClick = { vm.delUser = u }), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(u, 100.dp); Spacer(Modifier.height(6.dp)); Text(u, color = W, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("Tap = masuk  •  Tahan = hapus user", color = wa(0.6f), fontSize = 12.sp)
    }
}

// ============================ HOME (foto 2) ============================

@Composable
fun Tile(vm: Vm, id: String, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val size by animateDpAsState(if (selected) 128.dp else 88.dp, label = "tile")
    Box(
        Modifier.size(size).background(bgOf(id))
            .then(if (selected) Modifier.border(3.dp, W) else Modifier)
            .combinedClickable(onClick = onClick, onLongClick = onLong),
        contentAlignment = Alignment.Center
    ) { Art(vm.ctx, id) }
}

@Composable
fun HomeScreen(vm: Vm) {
    val ids = vm.homeList()
    var sel by remember { mutableStateOf(1) }
    val s = sel.coerceIn(0, ids.lastIndex)
    val ls = rememberLazyListState()
    LaunchedEffect(s) { ls.animateScrollToItem(s) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { vm.quick = true }) }
            .pointerInput(Unit) {
                var dy = 0f
                detectVerticalDragGestures(
                    onDragStart = { dy = 0f },
                    onDragEnd = { if (dy > 60f) vm.func = true },
                    onDragCancel = {}
                ) { _, d -> dy += d }
            }
    ) {
        Column(Modifier.fillMaxSize().padding(top = 6.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(CircleShape).combinedClickable(
                    onClick = { vm.toast("Tahan tombol PS untuk Quick Menu") },
                    onLongClick = { vm.quick = true }
                ).padding(6.dp)) {
                    Text("PS4", color = W, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                }
                Spacer(Modifier.weight(1f))
                Text("▾", color = wa(0.8f), fontSize = 22.sp, modifier = Modifier.clickable { vm.func = true }.padding(horizontal = 12.dp))
                Spacer(Modifier.weight(1f))
                val dot = when (vm.status) { "Online" -> Color(0xFF4CAF50); "Away" -> Color(0xFFFFB300); else -> Color(0xFF9E9E9E) }
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(6.dp))
                Text(vm.user ?: "", color = W, fontSize = 14.sp)
                Spacer(Modifier.width(14.dp))
                Clock()
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(
                state = ls,
                modifier = Modifier.fillMaxWidth().height(134.dp),
                contentPadding = PaddingValues(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                itemsIndexed(ids, key = { _, id -> id }) { i, id ->
                    Tile(vm, id, i == s,
                        onClick = { if (i != s) sel = i else vm.open(id) },
                        onLong = { vm.optId = id })
                }
            }
            Text(vm.title(ids[s]), color = W, fontSize = 18.sp, modifier = Modifier.padding(start = 24.dp, top = 6.dp, bottom = 6.dp))
            if (ids[s] == "whatsnew") WhatsNew(vm)
            else Text("Tap lagi untuk membuka  •  Tahan untuk opsi", color = wa(0.65f), fontSize = 13.sp, modifier = Modifier.padding(start = 24.dp))
        }
    }
}

@Composable
fun MiniTile(vm: Vm, id: String, size: Dp) {
    Box(Modifier.size(size).background(bgOf(id)).clickable { vm.open(id) }, contentAlignment = Alignment.Center) { Art(vm.ctx, id) }
}

@Composable
fun WhatsNew(vm: Vm) {
    val items = vm.recent.take(3)
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1f).background(Color.Black.copy(alpha = 0.25f)).padding(10.dp)) {
            Text("Recent Activity", color = W, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (items.isEmpty()) Text("Belum ada aktivitas. Buka sebuah aplikasi!", color = wa(0.7f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            items.forEach { r ->
                val id = r.substringBefore("|")
                val ts = r.substringAfter("|").toLongOrNull() ?: 0L
                Row(Modifier.fillMaxWidth().padding(top = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    MiniTile(vm, id, 30.dp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(vm.title(id), color = W, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(DateUtils.getRelativeTimeSpanString(ts, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), color = wa(0.6f), fontSize = 10.sp)
                    }
                }
            }
        }
        Column(Modifier.width(190.dp)) {
            Text("Now Playing", color = W, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            val np = vm.nowPlaying
            if (np == null) Text("—", color = wa(0.6f), fontSize = 12.sp)
            else Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                MiniTile(vm, np, 30.dp); Spacer(Modifier.width(8.dp))
                Text(vm.title(np), color = W, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Trending", color = W, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            val top = vm.counts.entries.sortedByDescending { it.value }.take(4)
            if (top.isEmpty()) Text("—", color = wa(0.6f), fontSize = 12.sp)
            else Row(Modifier.padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                top.forEach { MiniTile(vm, it.key, 36.dp) }
            }
        }
    }
}

// ============================ FUNCTION AREA (foto 4) ============================

@Composable
fun FuncArea(vm: Vm) {
    AnimatedVisibility(vm.func, enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()) {
        var sel by remember { mutableStateOf(9) }
        Box(
            Modifier.fillMaxSize().background(Color(0xCC000820))
                .pointerInput(Unit) { detectTapGestures { vm.func = false } }
                .pointerInput(Unit) {
                    var dy = 0f
                    detectVerticalDragGestures(
                        onDragStart = { dy = 0f },
                        onDragEnd = { if (dy < -50f) vm.func = false },
                        onDragCancel = {}
                    ) { _, d -> dy += d }
                }
        ) {
            Row(Modifier.align(Alignment.TopEnd).padding(20.dp)) { Clock() }
            LazyRow(
                Modifier.align(Alignment.Center).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(FUNCS) { i, f ->
                    val on = i == sel
                    val sz by animateDpAsState(if (on) 66.dp else 46.dp, label = "fn")
                    Column(
                        Modifier.width(78.dp).clickable { sel = i; vm.fn(f.id) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            PsIcon(f.icon, Modifier.size(sz), if (on) W else wa(0.65f))
                            if (f.id == "notif" && vm.recent.isNotEmpty())
                                Text("${minOf(vm.recent.size, 9)}", color = W, fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(if (on) f.label else "", color = W, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.height(32.dp))
                    }
                }
            }
            Text("Tarik ke atas / tap area kosong untuk menutup", color = wa(0.5f), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp))
        }
    }
}

// ============================ QUICK MENU (foto 5) ============================

@Composable
fun QRow(icon: String, label: String, sel: Boolean, on: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp)
            .then(if (sel) Modifier.border(2.dp, W) else Modifier)
            .clickable { on() }.padding(horizontal = 8.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PsIcon(icon, Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)); Text(label, color = W, fontSize = 15.sp)
    }
}

@Composable
fun QuickMenu(vm: Vm) {
    AnimatedVisibility(vm.quick, enter = slideInHorizontally { -it } + fadeIn(), exit = slideOutHorizontally { -it } + fadeOut()) {
        val qs = listOf(
            Q("close", "close", "Close Application") { vm.closeApp() },
            Q("sound", "speaker", "Sound/Devices") { vm.quick = false; vm.settings(Settings.ACTION_SOUND_SETTINGS) },
            Q("media", "play", "Media Player") { vm.open("music") },
            Q("np", "play", vm.nowPlaying?.let { vm.title(it) } ?: "Now Playing") { vm.nowPlaying?.let { vm.open(it) } },
            Q("party", "party", "Party") { vm.go(Scr.Party) },
            Q("status", "face", "Online Status") { vm.dlg = "status" },
            Q("friends", "friends", "Online Friends") { vm.go(Scr.Friends) },
            Q("power", "power", "Power") { vm.power = true }
        )
        Row(Modifier.fillMaxSize()) {
            Column(Modifier.width(300.dp).fillMaxHeight().background(Color(0xF2102F94)).padding(16.dp)) {
                Text("Quick Menu", color = W, fontSize = 22.sp)
                Spacer(Modifier.height(8.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    qs.filter { it.id !in vm.hiddenQ && !(it.id == "np" && vm.nowPlaying == null) }.forEach { q ->
                        if (q.id == "status") Box(Modifier.padding(vertical = 4.dp).fillMaxWidth().height(1.dp).background(wa(0.3f)))
                        QRow(q.icon, q.label, false) { q.on() }
                    }
                }
                QRow("lines", "Customise", vm.qsub != 0) { vm.qsub = 1 }
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(vm.user ?: "?", 24.dp); Spacer(Modifier.width(8.dp))
                    Text(vm.user ?: "", color = W, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${vm.battery()}%", color = W, fontSize = 12.sp)
                }
            }
            Box(
                Modifier.weight(1f).fillMaxHeight().background(Color(0x55000000))
                    .pointerInput(Unit) { detectTapGestures { if (vm.qsub != 0) { vm.qsub = 0 } else { vm.quick = false } } }
            ) {
                if (vm.qsub == 1) Column(Modifier.width(220.dp).padding(start = 16.dp, top = 50.dp)) {
                    QRow("wrench", "Menu Items", false) { vm.dlg = "menuitems" }
                    QRow("wrench", "Sort", false) { vm.dlg = "sort" }
                }
            }
        }
    }
}

// ============================ LIBRARY (foto 3) ============================

@Composable
fun LItem(icon: String, text: String, count: Int?, sel: Boolean, on: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().then(if (sel) Modifier.border(2.dp, W).background(wa(0.15f)) else Modifier)
            .clickable { on() }.padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PsIcon(icon, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp))
        Text(text, color = W, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (count != null) Text("$count", color = wa(0.8f), fontSize = 12.sp)
    }
}

@Composable
fun LibraryScreen(vm: Vm) {
    var filter by remember { mutableStateOf("apps") }
    var search by remember { mutableStateOf<String?>(null) }
    var order by remember { mutableStateOf(0) }
    val builtinIds = BUILTINS.map { it.id }.filter { it !in FIXED }
    val all = builtinIds + vm.lib
    val games = vm.lib.filter { vm.isGame(it) }
    val apps = builtinIds + vm.lib.filter { !vm.isGame(it) }
    var list = when (filter) { "all" -> all; "games" -> games; "android" -> vm.lib.toList(); else -> apps }
    val q = search
    if (q != null) list = list.filter { vm.title(it).contains(q, true) }
    list = when (order) {
        0 -> list.sortedBy { vm.title(it).lowercase() }
        1 -> list.sortedByDescending { vm.title(it).lowercase() }
        else -> list.sortedByDescending { vm.lastUsed(it) }
    }
    val orderNames = listOf("Name: A-Z", "Name: Z-A", "Recently Used")
    Frame(vm, "Library", right = { PsBtn("+ Add Android App") { vm.dlg = "addapp" } }) {
        Row(Modifier.weight(1f)) {
            Column(Modifier.width(190.dp).verticalScroll(rememberScrollState())) {
                LItem("search", "Search", null, q != null) { search = if (q == null) "" else null }
                Text("This PS4", color = wa(0.6f), fontSize = 11.sp, modifier = Modifier.padding(8.dp))
                LItem("grid", "All", all.size, filter == "all") { filter = "all" }
                LItem("gamepad", "Games", games.size, filter == "games") { filter = "games" }
                LItem("grid", "Applications", apps.size, filter == "apps") { filter = "apps" }
                Text(vm.user ?: "", color = wa(0.6f), fontSize = 11.sp, modifier = Modifier.padding(8.dp))
                LItem("bag", "Android Apps", vm.lib.size, filter == "android") { filter = "android" }
                LItem("plus", "PlayStation Plus", null, false) { vm.url("https://www.playstation.com/ps-plus/") }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (q != null) OutlinedTextField(
                        value = q, onValueChange = { search = it }, singleLine = true,
                        placeholder = { Text("Cari…") }, modifier = Modifier.weight(1f).heightIn(max = 56.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = W, unfocusedTextColor = W)
                    ) else Spacer(Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.border(1.dp, wa(0.6f)).clickable { order = (order + 1) % 3 }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(orderNames[order] + "  ▾", color = W, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (list.isEmpty()) Text("Kosong. Tekan “+ Add Android App” untuk menambah.", color = wa(0.7f), fontSize = 13.sp)
                LazyVerticalGrid(GridCells.Adaptive(190.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list) { id ->
                        Row(Modifier.combinedClickable(onClick = { vm.open(id) }, onLongClick = { vm.optId = id })) {
                            Box(Modifier.size(78.dp).background(bgOf(id)), contentAlignment = Alignment.Center) { Art(vm.ctx, id) }
                            Spacer(Modifier.width(8.dp))
                            Text(vm.title(id), color = W, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

// ============================ OTHER SCREENS ============================

@Composable
fun SettingsScreen(vm: Vm) {
    val s = listOf(
        Opt("Sound and Screen") { vm.settings(Settings.ACTION_SOUND_SETTINGS) },
        Opt("Display") { vm.settings(Settings.ACTION_DISPLAY_SETTINGS) },
        Opt("Network") { vm.settings(Settings.ACTION_WIFI_SETTINGS) },
        Opt("Devices (Bluetooth)") { vm.settings(Settings.ACTION_BLUETOOTH_SETTINGS) },
        Opt("Application Manager") { vm.settings(Settings.ACTION_APPLICATION_SETTINGS) },
        Opt("Storage") { vm.settings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) },
        Opt("Date and Time") { vm.settings(Settings.ACTION_DATE_SETTINGS) },
        Opt("Language") { vm.settings(Settings.ACTION_LOCALE_SETTINGS) },
        Opt("Accessibility") { vm.settings(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
        Opt("Battery") { vm.settings(Settings.ACTION_BATTERY_SAVER_SETTINGS) },
        Opt("Set as Default Launcher") { vm.settings(Settings.ACTION_HOME_SETTINGS) },
        Opt("System (Android)") { vm.settings(Settings.ACTION_SETTINGS) },
        Opt("Themes") { vm.dlg = "themes" },
        Opt("Initialization") { vm.dlg = "reset" }
    )
    Frame(vm, "Settings") {
        LazyVerticalGrid(GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(s) { o ->
                Row(Modifier.fillMaxWidth().background(wa(0.1f)).clickable { o.on() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    PsIcon("settings", Modifier.size(26.dp)); Spacer(Modifier.width(10.dp))
                    Text(o.label, color = W, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun TrophiesScreen(vm: Vm) {
    Frame(vm, "Trophies  (${vm.trophies.size}/${TROPHIES.size})") {
        LazyColumn {
            items(TROPHIES) { t ->
                val got = t.first in vm.trophies
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    PsIcon("trophy", Modifier.size(36.dp), if (got) Color(0xFFFFC72C) else wa(0.3f))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(t.second, color = if (got) W else wa(0.5f), fontSize = 16.sp)
                        Text(t.third, color = wa(0.55f), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun FriendsScreen(vm: Vm) {
    Frame(vm, "Friends", right = { PsBtn("+ Add Friend") { vm.dlg = "newfriend" } }) {
        if (vm.friends.isEmpty()) Text("Belum ada teman. Tekan “+ Add Friend”.", color = wa(0.7f), fontSize = 14.sp)
        LazyColumn {
            items(vm.friends.toList()) { f ->
                Row(Modifier.fillMaxWidth().clickable { vm.friendSel = f }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(f, 44.dp); Spacer(Modifier.width(12.dp))
                    Column { Text(f, color = W, fontSize = 16.sp); Text("Tap untuk opsi", color = wa(0.55f), fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
fun PartyScreen(vm: Vm) {
    Frame(vm, "Party") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(vm.user ?: "You", 56.dp); Spacer(Modifier.width(12.dp))
            Column { Text("${vm.user ?: "You"} (Host)", color = W, fontSize = 18.sp); Text("1/8 anggota", color = wa(0.6f), fontSize = 12.sp) }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PsBtn("Invite Friends") {
                vm.start(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Join my PS4 party!")
                }, "Invite"))
            }
            PsBtn("Voice Chat") { vm.openAny(listOf("com.discord", "com.whatsapp", "org.telegram.messenger"), null) }
            PsBtn("Leave Party") { vm.back() }
        }
    }
}

@Composable
fun NotesScreen(vm: Vm) {
    Frame(vm, "Notifications", right = { PsBtn("Clear") { vm.recent.clear(); vm.save() } }) {
        if (vm.recent.isEmpty()) Text("Tidak ada notifikasi.", color = wa(0.7f), fontSize = 14.sp)
        LazyColumn {
            items(vm.recent.toList()) { r ->
                val id = r.substringBefore("|")
                val ts = r.substringAfter("|").toLongOrNull() ?: 0L
                Row(Modifier.fillMaxWidth().clickable { vm.open(id) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MiniTile(vm, id, 40.dp); Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Anda membuka ${vm.title(id)}", color = W, fontSize = 14.sp)
                        Text(DateUtils.getRelativeTimeSpanString(ts, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), color = wa(0.55f), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RestOverlay(vm: Vm) {
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (vm.rest == 2) vm.scr = Scr.Users
                vm.rest = 0
            },
        contentAlignment = Alignment.Center
    ) {
        Text(if (vm.rest == 1) "Rest Mode — tap untuk membangunkan" else "PS4 mati — tap untuk menyalakan", color = Color(0x44FFFFFF), fontSize = 12.sp)
    }
}

// ============================ DIALOGS ============================

@Composable
fun ListDlg(title: String, opts: List<Opt>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F2F94), titleContentColor = W, textContentColor = W,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                opts.forEach { o ->
                    Text(o.label, color = W, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { o.on() }.padding(vertical = 11.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = W) } }
    )
}

@Composable
fun InputDlg(title: String, hint: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F2F94), titleContentColor = W, textContentColor = W,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = t, onValueChange = { t = it }, singleLine = true, placeholder = { Text(hint) },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = W, unfocusedTextColor = W)
            )
        },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onOk(t.trim()) }) { Text("OK", color = W) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = W) } }
    )
}

@Composable
fun AddAppDlg(vm: Vm) {
    val apps = remember { vm.installed() }
    AlertDialog(
        onDismissRequest = { vm.dlg = null },
        containerColor = Color(0xFF0F2F94), titleContentColor = W, textContentColor = W,
        title = { Text("Add Android Apps") },
        text = {
            LazyColumn(Modifier.heightIn(max = 230.dp)) {
                items(apps) { (pkg, name) ->
                    val id = "pkg:$pkg"
                    Row(Modifier.fillMaxWidth().clickable { vm.toggleAndroid(pkg) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp)) { Art(vm.ctx, id) }
                        Spacer(Modifier.width(10.dp))
                        Text(name, color = W, modifier = Modifier.weight(1f))
                        Checkbox(checked = id in vm.lib, onCheckedChange = { vm.toggleAndroid(pkg) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.dlg = null }) { Text("Done", color = W) } }
    )
}

@Composable
fun Dialogs(vm: Vm) {
    when (vm.dlg) {
        "newuser" -> InputDlg("New User", "Nama pengguna", { vm.dlg = null; vm.addUser(it) }) { vm.dlg = null }
        "newfriend" -> InputDlg("Add Friend", "Nama teman", { vm.dlg = null; vm.addFriend(it) }) { vm.dlg = null }
        "addapp" -> AddAppDlg(vm)
        "status" -> ListDlg("Online Status", listOf("Online", "Away", "Offline").map { s ->
            Opt(s) { vm.status = s; vm.save(); vm.dlg = null }
        }) { vm.dlg = null }
        "sort" -> ListDlg("Sort (urutan menu Home)", listOf("default" to "Default", "name" to "Name (A-Z)", "recent" to "Recently Used").map { (k, n) ->
            Opt(n) { vm.sort = k; vm.unlock("custom", "Personalizer"); vm.save(); vm.dlg = null }
        }) { vm.dlg = null }
        "menuitems" -> ListDlg("Menu Items", QITEMS.map { (id, name) ->
            Opt((if (id in vm.hiddenQ) "[   ]  " else "[✓]  ") + name) { vm.toggleQ(id) }
        }) { vm.dlg = null }
        "themes" -> ListDlg("Themes", THEME_NAMES.mapIndexed { i, n ->
            Opt(n) { vm.theme = i; vm.unlock("custom", "Personalizer"); vm.save(); vm.dlg = null }
        }) { vm.dlg = null }
        "reset" -> ListDlg("Initialization", listOf(
            Opt("Reset semua data launcher") { vm.reset(); vm.dlg = null },
            Opt("Cancel") { vm.dlg = null }
        )) { vm.dlg = null }
    }
    if (vm.power) ListDlg("Power", listOf(
        Opt("Enter Rest Mode") { vm.power = false; vm.quick = false; vm.rest = 1 },
        Opt("Log Out of PS4") { vm.power = false; vm.quick = false; vm.func = false; vm.scr = Scr.Users },
        Opt("Turn Off PS4") { vm.power = false; vm.quick = false; vm.func = false; vm.rest = 2 }
    )) { vm.power = false }
    vm.optId?.let { id ->
        val opts = mutableListOf(Opt("Open") { vm.optId = null; vm.open(id) })
        if (id in FIXED) opts.add(Opt("Unpin — terkunci") { vm.toast("${vm.title(id)} tidak bisa di-unpin") })
        else if (id in vm.home) opts.add(Opt("Unpin from Home") { vm.unpin(id); vm.optId = null })
        else opts.add(Opt("Pin to Home") { vm.pin(id); vm.optId = null })
        if (id.startsWith("pkg:")) {
            val p = id.removePrefix("pkg:")
            opts.add(Opt("App Info") { vm.start(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))) })
            opts.add(Opt("Remove from PS4") { vm.removeAndroid(p); vm.optId = null })
            opts.add(Opt("Uninstall") { vm.start(Intent(Intent.ACTION_DELETE, Uri.parse("package:$p"))) })
        }
        ListDlg(vm.title(id), opts) { vm.optId = null }
    }
    vm.friendSel?.let { f ->
        ListDlg(f, listOf(
            Opt("Invite to Party") {
                vm.friendSel = null
                vm.start(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Join my PS4 party, $f!")
                }, "Invite"))
            },
            Opt("Send Message") { vm.friendSel = null; vm.start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))) },
            Opt("Remove Friend") { vm.friends.remove(f); vm.save(); vm.friendSel = null }
        )) { vm.friendSel = null }
    }
    vm.delUser?.let { u ->
        ListDlg("Hapus user \"$u\"?", listOf(
            Opt("Delete") { vm.users.remove(u); vm.save(); vm.delUser = null },
            Opt("Cancel") { vm.delUser = null }
        )) { vm.delUser = null }
    }
}
