package com.kinzstudio.launcher

import android.Manifest
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Base64
import android.view.Gravity
import android.view.PixelCopy
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LimitedStream(ins: InputStream, private var left: Long) : FilterInputStream(ins) {
    override fun read(): Int {
        if (left <= 0) return -1
        val r = super.read()
        if (r >= 0) left--
        return r
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (left <= 0) return -1
        val n = super.read(b, off, minOf(len.toLong(), left).toInt())
        if (n > 0) left -= n.toLong()
        return n
    }
}

class AppRow(val pkg: String, val label: String, val icon: Drawable)

class MainActivity : ComponentActivity() {
    private val host = "appassets.androidplatform.net"
    private lateinit var web: WebView
    private lateinit var loader: WebViewAssetLoader
    private val prefs by lazy { getSharedPreferences("ps4native", MODE_PRIVATE) }
    private var immersive = true

    private var runPkg: String? = null
    private var runName = ""
    private var runAt = 0L

    private var onUris: ((List<Uri>) -> Unit)? = null
    private var chooserCb: ValueCallback<Array<Uri>>? = null
    private var permCb: ((Boolean) -> Unit)? = null
    private val clipFiles = HashMap<String, File>()

    private val AUDIO = setOf("mp3", "wav", "ogg", "oga", "flac", "m4a", "aac", "opus", "weba")
    private val VIDEO = setOf("mp4", "webm", "mkv", "mov", "m4v", "ogv", "3gp")
    private val IMAGE = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "avif")

    private val docLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        val l = ArrayList<Uri>()
        if (r.resultCode == RESULT_OK && d != null) {
            d.data?.let { l.add(it) }
            d.clipData?.let { c -> for (i in 0 until c.itemCount) l.add(c.getItemAt(i).uri) }
        }
        val cb = onUris
        onUris = null
        cb?.invoke(l.distinct())
    }

    private val chooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = chooserCb
        chooserCb = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { m ->
        val cb = permCb
        permCb = null
        cb?.invoke(m.values.all { it })
    }

    // ------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        immersive = prefs.getBoolean("fs", true)
        try { cacheDir.listFiles()?.filter { it.name.startsWith("clip_") }?.forEach { it.delete() } } catch (e: Exception) { }

        loader = WebViewAssetLoader.Builder()
            .setDomain(host)
            .addPathHandler("/app/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B3D9F"))
        setContentView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            textZoom = 100
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val r = request ?: return null
                val u = r.url
                if (u.host == host && (u.path ?: "").startsWith("/media/")) return media(r)
                val res = loader.shouldInterceptRequest(u)
                if (res == null && u.host == host) {
                    return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", HashMap<String, String>(), ByteArrayInputStream(ByteArray(0)))
                }
                return res
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return request?.url?.host != host
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                recreate()
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                val req = request ?: return
                runOnUiThread {
                    if (req.origin.host != host) { req.deny(); return@runOnUiThread }
                    val need = ArrayList<String>()
                    if (req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) need.add(Manifest.permission.CAMERA)
                    if (req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) need.add(Manifest.permission.RECORD_AUDIO)
                    val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                    if (missing.isEmpty()) req.grant(req.resources)
                    else {
                        permCb = { ok -> if (ok) req.grant(req.resources) else req.deny() }
                        permLauncher.launch(missing.toTypedArray())
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                val cb = filePathCallback ?: return false
                val p = fileChooserParams ?: return false
                chooserCb?.onReceiveValue(null)
                chooserCb = cb
                return try {
                    chooserLauncher.launch(p.createIntent())
                    true
                } catch (e: Exception) {
                    chooserCb = null
                    cb.onReceiveValue(null)
                    false
                }
            }
        }
        web.loadUrl("https://$host/app/index.html")
        web.requestFocus()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                js("document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))")
            }
        })
        applyImmersive()
    }

    override fun onResume() {
        super.onResume()
        val p = runPkg
        if (p != null && System.currentTimeMillis() - runAt > 1500) {
            val n = runName
            runPkg = null
            sendEvent("exit", JSONObject().put("name", n).put("code", 0))
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    // ------------------------------------------------------------ helpers
    private fun js(code: String) { web.evaluateJavascript(code, null) }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun err(m: String) = JSONObject().put("ok", false).put("error", m)

    private fun reply(id: Int, v: Any?) {
        val s = (v ?: JSONObject.NULL).toString()
        runOnUiThread { web.evaluateJavascript("window.__ab($id,${JSONObject.quote(s)})", null) }
    }

    private fun sendEvent(name: String, v: JSONObject?) {
        val s = (v ?: JSONObject.NULL).toString()
        runOnUiThread { web.evaluateJavascript("window.__abEvent(${JSONObject.quote(name)},${JSONObject.quote(s)})", null) }
    }

    private fun bg(id: Int, f: () -> Unit) {
        Thread {
            try { f() } catch (e: Exception) { reply(id, err(e.message ?: "error")) }
        }.start()
    }

    private fun applyImmersive() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (immersive) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    private fun capDir(): File {
        val base = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
        val d = File(base, "Launcher Captures")
        d.mkdirs()
        return d
    }

    private fun kindOf(mime: String?, name: String): String? {
        val m = mime ?: ""
        if (m.startsWith("audio/")) return "audio"
        if (m.startsWith("video/")) return "video"
        if (m.startsWith("image/")) return "image"
        val e = name.substringAfterLast('.', "").lowercase()
        return when {
            e in AUDIO -> "audio"
            e in VIDEO -> "video"
            e in IMAGE -> "image"
            else -> null
        }
    }

    private fun persist(l: List<Uri>) {
        for (u in l) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        }
    }

    private fun iconUrl(d: Drawable): String {
        val bmp = d.toBitmap(128, 128)
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
        return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    // ------------------------------------------------------------ media server (Range support)
    private fun skipFully(ins: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val s = ins.skip(left)
            if (s <= 0) { if (ins.read() < 0) break else left-- } else left -= s
        }
    }

    private fun media(req: WebResourceRequest): WebResourceResponse? {
        return try {
            val id = req.url.lastPathSegment ?: return null
            val path = String(Base64.decode(id, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8)
            val uri = if (path.startsWith("content://")) Uri.parse(path) else Uri.fromFile(File(path))
            val afd = contentResolver.openAssetFileDescriptor(uri, "r") ?: return null
            val total = afd.length
            val mime = contentResolver.getType(uri)
                ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(path.substringAfterLast('.', "").lowercase())
                ?: "application/octet-stream"
            val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
            val h = HashMap<String, String>()
            h["Accept-Ranges"] = "bytes"
            h["Access-Control-Allow-Origin"] = "*"
            if (range != null && total > 0 && range.startsWith("bytes=")) {
                val p = range.removePrefix("bytes=").split("-")
                val start = p[0].toLongOrNull() ?: 0L
                val end = (p.getOrNull(1)?.toLongOrNull() ?: (total - 1)).coerceAtMost(total - 1)
                if (start > end) {
                    afd.close()
                    return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h, ByteArrayInputStream(ByteArray(0)))
                }
                val ins = afd.createInputStream()
                skipFully(ins, start)
                h["Content-Range"] = "bytes $start-$end/$total"
                h["Content-Length"] = (end - start + 1).toString()
                WebResourceResponse(mime, null, 206, "Partial Content", h, LimitedStream(ins, end - start + 1))
            } else {
                if (total > 0) h["Content-Length"] = total.toString()
                WebResourceResponse(mime, null, 200, "OK", h, afd.createInputStream())
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ JS bridge
    inner class Bridge {
        @JavascriptInterface
        fun invoke(id: Int, method: String, args: String) {
            runOnUiThread {
                try { dispatch(id, method, JSONArray(args)) }
                catch (e: Exception) { reply(id, err(e.message ?: "error")) }
            }
        }

        @JavascriptInterface
        fun chunk(token: String, b64: String): Boolean {
            return try {
                val f = synchronized(clipFiles) {
                    clipFiles.getOrPut(token) { File(cacheDir, "clip_" + token.filter { it.isLetterOrDigit() }) }
                }
                FileOutputStream(f, true).use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                true
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun dispatch(id: Int, m: String, a: JSONArray) {
        when (m) {
            "pickFiles" -> pickApps { reply(id, it) }
            "pickFile" -> pickDocs(arrayOf("*/*"), false) { l ->
                bg(id) { persist(l); reply(id, JSONArray(l.mapNotNull { fileEntry(it) })) }
            }
            "launch" -> reply(id, launch(a.optString(0), a.optJSONObject(1)))
            "closeGame" -> reply(id, closeGame())
            "makeShortcut" -> reply(id, makeShortcut(a.optJSONObject(0)))
            "version" -> reply(id, JSONObject().put("version", "1.3.0").put("electron", "android").put("chrome", chromeVersion()))
            "setStartFs" -> { prefs.edit().putBoolean("fs", a.optBoolean(0, true)).apply(); reply(id, true) }
            "openUrl" -> reply(id, openUrl(a.optString(0)))
            "pickMedia" -> {
                val kind = if (a.isNull(0)) "" else a.optString(0)
                val types = when (kind) {
                    "audio" -> arrayOf("audio/*")
                    "video" -> arrayOf("video/*")
                    "image" -> arrayOf("image/*")
                    else -> arrayOf("audio/*", "video/*", "image/*")
                }
                pickDocs(types, true) { l -> bg(id) { persist(l); reply(id, JSONArray(l.mapNotNull { mediaEntry(it) })) } }
            }
            "pickMediaFolder" -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                onUris = { l ->
                    bg(id) {
                        val tree = l.firstOrNull()
                        if (tree == null) reply(id, JSONArray())
                        else {
                            persist(listOf(tree))
                            val out = ArrayList<JSONObject>()
                            scanTree(tree, DocumentsContract.getTreeDocumentId(tree), 3, out)
                            out.sortWith(compareBy<JSONObject> { it.optString("n").lowercase() })
                            reply(id, JSONArray(out))
                        }
                    }
                }
                try { docLauncher.launch(i) } catch (e: Exception) { onUris = null; reply(id, JSONArray()) }
            }
            "capList" -> bg(id) { reply(id, capList()) }
            "capShot" -> capShot(id)
            "capOpen" -> {
                Toast.makeText(this, "Tangkapan tersimpan di: " + capDir().absolutePath, Toast.LENGTH_LONG).show()
                reply(id, JSONObject().put("ok", true))
            }
            "capDel" -> reply(id, capDel(a.optString(0)))
            "saveEnd" -> bg(id) { reply(id, saveEnd(a.optString(0), a.optString(1))) }
            "fullscreen" -> { immersive = !immersive; applyImmersive(); reply(id, immersive) }
            "quit" -> { reply(id, true); finishAffinity() }
            else -> reply(id, err("Perintah tidak dikenal: $m"))
        }
    }

    // ------------------------------------------------------------ pickers
    private fun pickDocs(types: Array<String>, multi: Boolean, cb: (List<Uri>) -> Unit) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        if (types.size > 1 || types[0] != "*/*") i.putExtra(Intent.EXTRA_MIME_TYPES, types)
        onUris = cb
        try { docLauncher.launch(i) } catch (e: Exception) { onUris = null; cb(emptyList()) }
    }

    private fun nameAndSize(uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment ?: "file"
        var size = 0L
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    if (!c.isNull(0)) name = c.getString(0)
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        } catch (e: Exception) { }
        return Pair(name, size)
    }

    private fun mediaEntry(uri: Uri): JSONObject? {
        val (name, size) = nameAndSize(uri)
        val kind = kindOf(contentResolver.getType(uri), name) ?: return null
        return JSONObject().put("n", name.substringBeforeLast('.')).put("path", uri.toString())
            .put("kind", kind).put("size", size).put("t", System.currentTimeMillis())
    }

    private fun fileEntry(uri: Uri): JSONObject? {
        val (name, size) = nameAndSize(uri)
        val ext = name.substringAfterLast('.', "").uppercase().ifEmpty { "FILE" }
        return JSONObject().put("n", name.substringBeforeLast('.')).put("ext", ext)
            .put("size", size).put("path", uri.toString())
    }

    private fun scanTree(tree: Uri, docId: String, depth: Int, out: MutableList<JSONObject>) {
        if (depth < 0 || out.size >= 500) return
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        val dirs = ArrayList<String>()
        try {
            contentResolver.query(kids, cols, null, null, null)?.use { c ->
                while (c.moveToNext() && out.size < 500) {
                    val did = c.getString(0)
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (!name.startsWith(".")) dirs.add(did)
                    } else {
                        val k = kindOf(mime, name) ?: continue
                        out.add(
                            JSONObject().put("n", name.substringBeforeLast('.'))
                                .put("path", DocumentsContract.buildDocumentUriUsingTree(tree, did).toString())
                                .put("kind", k).put("size", if (c.isNull(3)) 0L else c.getLong(3))
                                .put("t", if (c.isNull(4)) 0L else c.getLong(4))
                        )
                    }
                }
            }
        } catch (e: Exception) { }
        for (d in dirs) scanTree(tree, d, depth - 1, out)
    }

    // ------------------------------------------------------------ pilih app Android (menu "Add Game")
    private fun pickApps(done: (JSONArray) -> Unit) {
        Thread {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val rows = pm.queryIntentActivities(i, 0)
                .map { AppRow(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .filter { it.pkg != packageName }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { showAppDialog(rows, done) }
        }.start()
    }

    private fun showAppDialog(rows: List<AppRow>, done: (JSONArray) -> Unit) {
        val checked = BooleanArray(rows.size)
        val lv = ListView(this)
        lv.divider = null
        val adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(12), dp(6), dp(12), dp(6))
                val iv = ImageView(this@MainActivity)
                iv.setImageDrawable(rows[p].icon)
                row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                val tv = TextView(this@MainActivity)
                tv.text = rows[p].label
                tv.setTextColor(Color.WHITE)
                tv.textSize = 16f
                tv.setPadding(dp(12), 0, dp(8), 0)
                row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val cb = CheckBox(this@MainActivity)
                cb.isChecked = checked[p]
                cb.isClickable = false
                cb.isFocusable = false
                row.addView(cb)
                return row
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ -> checked[pos] = !checked[pos]; adapter.notifyDataSetChanged() }
        val title = TextView(this)
        title.text = "Pilih aplikasi Android"
        title.setTextColor(Color.WHITE)
        title.textSize = 20f
        title.setPadding(dp(20), dp(16), dp(20), dp(8))
        val dlg = AlertDialog.Builder(this)
            .setCustomTitle(title)
            .setView(lv)
            .setPositiveButton("Tambah") { _, _ ->
                Thread {
                    val out = JSONArray()
                    rows.forEachIndexed { i, r ->
                        if (checked[i]) {
                            val size = try { File(packageManager.getApplicationInfo(r.pkg, 0).sourceDir).length() } catch (e: Exception) { 0L }
                            out.put(
                                JSONObject().put("n", r.label).put("ext", "APP").put("size", size)
                                    .put("path", "android:" + r.pkg).put("icon", iconUrl(r.icon))
                            )
                        }
                    }
                    done(out)
                }.start()
            }
            .setNegativeButton("Batal") { _, _ -> done(JSONArray()) }
            .setOnCancelListener { done(JSONArray()) }
            .create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#0B3D9F")))
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.WHITE)
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.WHITE)
    }

    // ------------------------------------------------------------ menjalankan app / url
    private fun launch(path: String, opts: JSONObject?): JSONObject {
        val name = opts?.optString("name").orEmpty()
        return try {
            if (path.startsWith("android:")) {
                val pkg = path.removePrefix("android:")
                val i = packageManager.getLaunchIntentForPackage(pkg) ?: return err("Aplikasi tidak terpasang: $pkg")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                runPkg = pkg
                runName = name.ifEmpty { pkg }
                runAt = System.currentTimeMillis()
                JSONObject().put("ok", true).put("tracked", true).put("pid", 1)
            } else if (path.startsWith("content://")) {
                val uri = Uri.parse(path)
                val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, contentResolver.getType(uri) ?: "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                JSONObject().put("ok", true)
            } else err("Jenis item ini tidak bisa dibuka di Android")
        } catch (e: Exception) {
            err(e.message ?: "Gagal membuka")
        }
    }

    private fun closeGame(): JSONObject {
        val p = runPkg ?: return err("Tidak ada aplikasi yang dilacak")
        try { (getSystemService(ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(p) } catch (e: Exception) { }
        val n = runName
        runPkg = null
        sendEvent("exit", JSONObject().put("name", n).put("code", 0))
        return JSONObject().put("ok", true)
    }

    private fun openUrl(u: String): JSONObject {
        if (!Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(u)) return err("Alamat tidak valid")
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().put("ok", true)
        } catch (e: Exception) {
            err(e.message ?: "Gagal membuka")
        }
    }

    private fun makeShortcut(it: JSONObject?): JSONObject {
        val path = it?.optString("path").orEmpty()
        val name = it?.optString("n").orEmpty().ifEmpty { "App" }
        if (!path.startsWith("android:")) return err("Shortcut hanya untuk aplikasi Android")
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) return err("Launcher HP tidak mendukung shortcut")
        return try {
            val pkg = path.removePrefix("android:")
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return err("Aplikasi tidak terpasang")
            val icon = IconCompat.createWithBitmap(packageManager.getApplicationIcon(pkg).toBitmap(192, 192))
            val info = ShortcutInfoCompat.Builder(this, "ps4_$pkg").setShortLabel(name).setIntent(intent).setIcon(icon).build()
            ShortcutManagerCompat.requestPinShortcut(this, info, null)
            JSONObject().put("ok", true)
        } catch (e: Exception) {
            err(e.message ?: "Gagal membuat shortcut")
        }
    }

    private fun chromeVersion(): String =
        try { WebView.getCurrentWebViewPackage()?.versionName ?: "WebView" } catch (e: Exception) { "WebView" }

    // ------------------------------------------------------------ Capture Gallery
    private fun capList(): JSONObject {
        val items = ArrayList<JSONObject>()
        capDir().listFiles()?.forEach { f ->
            if (f.isFile) {
                val k = kindOf(null, f.name)
                if (k == "image" || k == "video") {
                    items.add(
                        JSONObject().put("n", f.nameWithoutExtension).put("path", f.absolutePath)
                            .put("kind", k).put("size", f.length()).put("t", f.lastModified())
                    )
                }
            }
        }
        items.sortByDescending { it.optLong("t") }
        return JSONObject().put("dir", capDir().absolutePath).put("items", JSONArray(items))
    }

    private fun capShot(id: Int) {
        val v = window.decorView
        if (v.width <= 0 || v.height <= 0) { reply(id, err("Layar belum siap")); return }
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        try {
            PixelCopy.request(window, bmp, { res ->
                if (res == PixelCopy.SUCCESS) {
                    bg(id) {
                        val f = File(capDir(), "Screenshot-" + stamp() + ".png")
                        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        reply(id, JSONObject().put("ok", true).put("path", f.absolutePath))
                    }
                } else reply(id, err("Screenshot gagal"))
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            reply(id, err(e.message ?: "Screenshot gagal"))
        }
    }

    private fun capDel(p: String): JSONObject {
        return try {
            val f = File(p).canonicalFile
            val root = capDir().canonicalPath + File.separator
            if (!f.path.startsWith(root) || !f.isFile) err("File tidak diizinkan")
            else { f.delete(); JSONObject().put("ok", true) }
        } catch (e: Exception) {
            err(e.message ?: "Gagal menghapus")
        }
    }

    private fun saveEnd(token: String, ext: String): JSONObject {
        val src = synchronized(clipFiles) { clipFiles.remove(token) }
        if (src == null || !src.exists()) return err("Data klip kosong")
        val png = ext == "png"
        val dest = File(capDir(), (if (png) "Photo-" else "SHAREfactory-") + stamp() + "." + (if (png) "png" else "webm"))
        if (!src.renameTo(dest)) {
            src.copyTo(dest, overwrite = true)
            src.delete()
        }
        return JSONObject().put("ok", true).put("path", dest.absolutePath)
    }
}
