/* Jembatan Android: mendefinisikan window.launcher (API yang sama dengan preload.js versi PC)
   di atas AndroidBridge (Kotlin). index.html tidak perlu tahu bedanya. */
(function () {
  var B = window.AndroidBridge;
  if (!B) return;
  var pend = {}, seq = 0, cbs = { exit: [], cap: [] };

  window.__ab = function (id, json) {
    var p = pend[id];
    if (!p) return;
    delete pend[id];
    var v = null;
    try { v = JSON.parse(json); } catch (e) { v = null; }
    p(v);
  };
  window.__abEvent = function (name, json) {
    var d = null;
    try { d = JSON.parse(json); } catch (e) { d = null; }
    (cbs[name] || []).forEach(function (f) { try { f(d); } catch (e) { /* ignore */ } });
  };

  function call(m, a) {
    return new Promise(function (res) {
      var id = ++seq;
      pend[id] = res;
      try { B.invoke(id, m, JSON.stringify(a || [])); }
      catch (e) { delete pend[id]; res(null); }
    });
  }
  function b64url(s) {
    return btoa(unescape(encodeURIComponent(s))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function fileUrl(p) { return 'https://appassets.androidplatform.net/media/' + b64url(String(p)); }

  window.launcher = {
    isElectron: true,
    platform: 'android',
    pickFiles: function () { return call('pickFiles'); },      // dialog pilih app Android
    pickFolder: function () { return call('pickFile'); },      // pilih satu file dari HP
    getPaths: function () { return []; },
    describe: function () { return Promise.resolve([]); },
    launch: function (p, o) { return call('launch', [p, o || {}]); },
    closeGame: function () { return call('closeGame'); },
    onGameExit: function (cb) { if (typeof cb === 'function') cbs.exit.push(cb); },
    makeShortcut: function (it) { return call('makeShortcut', [it]); },
    version: function () { return call('version'); },
    setStartFullscreen: function (on) { return call('setStartFs', [!!on]); },
    openUrl: function (u, o) { return call('openUrl', [u, o || {}]); },
    pickMedia: function (k) { return call('pickMedia', [k || '']); },
    pickMediaFolder: function () { return call('pickMediaFolder'); },
    readFile: function (p) {
      return fetch(fileUrl(p)).then(function (r) { return r.ok ? r.arrayBuffer() : null; }).catch(function () { return null; });
    },
    capList: function () { return call('capList'); },
    capShot: function () { return call('capShot'); },
    capOpen: function () { return call('capOpen'); },
    capDel: function (p) { return call('capDel', [p]); },
    saveClip: function (buf, ext) {
      return new Promise(function (res) {
        var t = 'c' + Date.now() + '_' + (++seq);
        var u8 = new Uint8Array(buf), step = 3 * 174762, i = 0, bad = false;
        (function next() {
          if (bad) { res({ ok: false, error: 'Gagal menulis file' }); return; }
          if (i >= u8.length) { call('saveEnd', [t, ext]).then(res); return; }
          var sl = u8.subarray(i, i + step);
          i += step;
          var s = '';
          for (var k = 0; k < sl.length; k += 8192) s += String.fromCharCode.apply(null, sl.subarray(k, k + 8192));
          try { if (!B.chunk(t, btoa(s))) bad = true; } catch (e) { bad = true; }
          setTimeout(next, 0);
        })();
      });
    },
    onCapture: function (cb) { if (typeof cb === 'function') cbs.cap.push(cb); },
    quit: function () { return call('quit'); },
    toggleFullscreen: function () { return call('fullscreen'); },
    fileUrl: fileUrl
  };
})();
