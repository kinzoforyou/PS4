Suara menu
==========
Secara bawaan launcher memakai suara sintetis bergaya PS4 (dibuat lewat WebAudio, tanpa file).

Mau pakai suara asli / suara sendiri? Taruh file .mp3 di folder ini dengan nama:

  move.mp3   saat memindah pilihan (kursor)
  ok.mp3     saat menekan Enter / memilih
  back.mp3   saat kembali (Esc) atau menutup Quick Menu
  open.mp3   saat membuka game / aplikasi

File yang ada otomatis dipakai menggantikan suara bawaan. Volume diatur di
Settings > Sound and Screen atau Quick Menu > Sound/Devices.
